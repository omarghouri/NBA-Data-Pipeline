# DEEPSEEK_USAGE

## Model
- deepseek-chat

## Prompt pattern
- Role tag selection from a controlled list
- Single sentence blurb capped at ~25 words
- Impact score 0 to 100 with rubric

## Notes
- Response requested as strict JSON for easy parsing
- Added clamp and defaults to keep the pipeline resilient

## Example cost
- Not estimated per assignment instructions, use the shared credits.
